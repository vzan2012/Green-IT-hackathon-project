import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-popular-people-section',
  templateUrl: './popular-people-section.component.html',
  styleUrls: ['./popular-people-section.component.css']
})
export class PopularPeopleSectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}