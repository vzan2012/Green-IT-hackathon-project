import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-latest-movie-news',
  templateUrl: './latest-movie-news.component.html',
  styleUrls: ['./latest-movie-news.component.css']
})
export class LatestMovieNewsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
