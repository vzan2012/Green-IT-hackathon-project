import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

import { IMovieCard } from '../movie-card';
import { MoviesService } from '../movies.service';


@Component({
  selector: 'app-movie-detailed-view',
  templateUrl: './movie-detailed-view.component.html',
  styleUrls: ['./movie-detailed-view.component.css']
})
export class MovieDetailedViewComponent implements OnInit {

  public getMovieDetailed: IMovieCard[];

  constructor(private route: ActivatedRoute, private _location: Location, private moviesService: MoviesService) { }

  ngOnInit():void {

    this.getMovieDetails();

  }

  getMovieDetails() : void {
    const id = +this.route.snapshot.paramMap.get('id');
    // console.log(id);
    this.moviesService.getMovieDetails(id).subscribe(data => this.getMovieDetailed = data);
  }


  backClicked(): void {
    this._location.back();
  }


}
