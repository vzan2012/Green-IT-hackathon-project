export interface IMovies {
    id: number,
    title: string,
    poster_path: string,
    backdrop_path: string,
    overview: string,
    release_date: string
}