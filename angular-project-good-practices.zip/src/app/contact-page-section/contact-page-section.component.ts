import { Component, OnInit } from '@angular/core';

// import * as $ from 'jquery';

@Component({
  selector: 'app-contact-page-section',
  templateUrl: './contact-page-section.component.html',
  styleUrls: ['./contact-page-section.component.css']
})
export class ContactPageSectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    //console.log("ContactPage");
  }

}
