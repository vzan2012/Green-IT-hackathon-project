import { Component, OnInit } from '@angular/core';
import { MoviesService } from '../movies.service';

import { Router } from '@angular/router';

@Component({
  selector: 'app-popular-movies',
  templateUrl: './popular-movies.component.html',
  styleUrls: ['./popular-movies.component.css']
})
export class PopularMoviesComponent implements OnInit {

  public getPopularMovieCard = []

  public errorMsg;

  constructor(private _movieService: MoviesService, private router: Router) { }

  ngOnInit() {
    this._movieService.getPopularMovieCard().subscribe(data => this.getPopularMovieCard = data,
                                                        error => this.errorMsg = error);
  }

  // onSelect(mcard) {
  //   this.router.navigate(['/movies', mcard.id]);
  // }


}
