import { NgModule } from '@angular/core';
import { RouterModule, Routes, Router } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';

import { HomeContentComponent } from './home-content/home-content.component'
import { PopularPeopleSectionComponent } from './popular-people-section/popular-people-section.component';
import { ContactPageSectionComponent } from './contact-page-section/contact-page-section.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { PopularMoviesComponent } from './popular-movies/popular-movies.component';
import { MovieDetailedViewComponent } from './movie-detailed-view/movie-detailed-view.component';

const routes: Routes = [
  {path: '', redirectTo: '/home', pathMatch: 'full'},
  {path: 'home', component: HomeContentComponent},
  {path: 'popular-people', component: PopularPeopleSectionComponent},
  {path: 'popular-movies', component: PopularMoviesComponent},
  {path: 'movie-details/:id', component: MovieDetailedViewComponent},
  {path: 'contact', component: ContactPageSectionComponent}
  // {path: "**", component: PageNotFoundComponent}
];

@NgModule({
  imports: [ RouterModule.forRoot(routes, {onSameUrlNavigation: 'reload'})],
  exports: [ RouterModule ]
})

export class AppRoutingModule { 

}
